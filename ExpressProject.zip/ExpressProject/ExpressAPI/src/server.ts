import express from "express";
import * as bodyParser from "body-parser";

// run these commands in two different terminals to start the service.
// 1. npm run watch-node
// 2. npm run watch-ts

// tslint:disable-next-line: typedef
const app = express();
app.use(bodyParser.json());

// tslint:disable-next-line:typedef
const router = express.Router();
router.get("/", (request, response) => {
    response.send("Hello");
});
router.post("/v1/parse", (request, response) => {
    response.send(v1Parser(request.body));
});
router.post("/v2/parse", (request, response) => {
    response.send(v2Parser(request.body));
});
app.use("/api", router);

app.listen(3000, () => console.log("App listening on port 3000!"));

function v1Parser(req: IRequestData): IResponseData {
    // tslint:disable-next-line:typedef
    const response = {} as IResponseData;
    response.firstName = req.data.slice(0, 8);
    response.lastName = req.data.slice(8, 18);
    response.clientId = req.data.slice(-7);
    return response;
}

function v2Parser(req: IRequestData): IResponseData {
    // tslint:disable-next-line:typedef
    const response = {} as IResponseData;
    // tslint:disable-next-line:typedef
    const clientId = req.data.slice(-7);
    response.firstName = req.data.slice(0, 4);
    response.lastName = req.data.slice(8, 15);
    response.clientId = [clientId.slice(0, 3), "-", clientId.slice(3)].join("");
    return response;
}

export interface IRequestData {
    data: any;
}

export interface IResponseData {
    firstName: any;
    lastName: any;
    clientId: any;
}
